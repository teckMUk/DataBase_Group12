import "./dashboard.css";
import Nav from '../../components/nav/nav';
import {Link} from 'react-router-dom';


export default function Home()
{
    return(
      <div> 

        <Nav/>

        <h2 class = "section-heading"> Dashboard </h2>
      
      
      <div class="column-4 project-2">
        <h2 class="project-text"> <Link to = '/create_account'> Create Account </Link> <br /> </h2>
       
      </div>
      
      <div class="column-4 project-3">
        <h2 class="project-text">View my profile </h2>
      </div>
      
      <div class="column-4 project-4">
        <h2 class="project-text">View invoices </h2>
      </div>
      
      <div class="column-4 project-5">
        <h2 class="project-text">Edit employees' details </h2>
      </div>
      
      
      </div>
    )
}