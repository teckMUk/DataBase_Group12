import React from 'react';
import './header.css';


export default function Header()
{
    return (
        <header>
	        <div className="overlay">
                <h1> </h1>
                <h1> </h1>
                <h1> </h1>
                <h1>The Dumpling</h1>
                <h3>Here is to serving the best continental in town!</h3>
	            
		    </div>
            
        </header>
       
        
    )
}